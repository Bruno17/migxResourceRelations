<?php
class rrResourceRelation extends xPDOSimpleObject {}