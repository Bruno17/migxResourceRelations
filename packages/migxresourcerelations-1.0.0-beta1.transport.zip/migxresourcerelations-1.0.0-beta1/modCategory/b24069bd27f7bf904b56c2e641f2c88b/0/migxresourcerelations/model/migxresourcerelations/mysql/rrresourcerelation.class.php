<?php
require_once (dirname(dirname(__FILE__)) . '/rrresourcerelation.class.php');
class rrResourceRelation_mysql extends rrResourceRelation {}