<?php

$this->customconfigs['sourceortarget'] = 'target';

$this->customconfigs['sortConfig'] = '
[{"sortby":"rrResourceRelation.pos","sortdir":"ASC"},{"sortby":"Source.id","sortdir":"ASC"}]
';