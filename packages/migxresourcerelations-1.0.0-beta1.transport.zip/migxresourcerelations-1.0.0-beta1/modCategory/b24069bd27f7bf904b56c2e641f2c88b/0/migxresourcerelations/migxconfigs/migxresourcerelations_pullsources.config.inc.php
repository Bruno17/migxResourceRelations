<?php

$this->customconfigs['sortConfig'] = '
[{"sortby":"Parent.pagetitle","sortdir":"ASC"},{"sortby":"modResource.pagetitle","sortdir":"ASC"}]
';

$this->customconfigs['sourceortarget'] = 'pullsources';
$this->customconfigs['selectfields'] = 'id,pagetitle';